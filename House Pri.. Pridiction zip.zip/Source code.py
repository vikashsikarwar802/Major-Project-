# %%
# CELL 1: IMPORTS

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn import metrics

import ipywidgets as widgets
from IPython.display import display, HTML, clear_output

# %%
# CELL 2: LOAD DATASE

#csv_path = "C:/Users/sr975/Pictures/Screenshots/ITM notes/HousePriceDataset_300 (1).csv"
csv_path = "C:/Users/sr975/Pictures/Screenshots/ITM notes/house price 15k.csv"
#csv_path = "C:/Users/sr975/Pictures/Screenshots/ITM notes/house_price_5000_raw.csv"
#csv_path = "C:/Users/sr975/Downloads/house_price_raw_40k_rows.csv"

df = pd.read_csv(csv_path)

print("✅ Dataset Loaded Successfully!")
print("Shape:", df.shape)
display(df.head())

# %%
# CELL 3-EDA

print("\n📊 Info:")
display(df.info())

print("\n❌ Missing Values:")
print(df.isna().sum())

print("\n📈 Statistics:")
display(df.describe())

num_cols = df.select_dtypes(include=[np.number]).columns.tolist()

if num_cols:
    df[num_cols].hist(figsize=(12,8))
    plt.show()

# Heatmap
plt.figure(figsize=(10,6))
sns.heatmap(df[num_cols].corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()

# %%
# CELL 4: PREPROCESSING

target_col = "price"   # ⚠️ check your CSV (lowercase/uppercase)

if target_col not in df.columns:
    raise KeyError(f"column'{target_col}' not found!")

df_proc = df.copy()

# Fill missing values
for col in df_proc.columns:
    if df_proc[col].isna().sum() > 0:
        if df_proc[col].dtype in [np.float64, np.int64]:
            df_proc[col] = df_proc[col].fillna(df_proc[col].median())
        else:
            df_proc[col] = df_proc[col].fillna(df_proc[col].mode()[0])

# Split
X = df_proc.drop(columns=[target_col])
y = df_proc[target_col]

# Store for dashboard
original_columns = X.columns.tolist()
original_dtypes = X.dtypes.to_dict()
original_df = X.copy()

# Encoding
cat_cols = X.select_dtypes(include=['object']).columns.tolist()

if cat_cols:
    X = pd.get_dummies(X, columns=cat_cols, drop_first=True)

encoded_columns = X.columns.tolist()

print("✅ Features:", X.shape)

# %%
# CELL 5: TRAIN TEST SPLIT

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print("🔀 Train Shape:", X_train.shape)
print("🔀 Test Shape:", X_test.shape)

# %%
# CELL 6: LINEAR REGRESSION

lr = LinearRegression()
lr.fit(X_train, y_train)
y_pred_lr = lr.predict(X_test)

def print_regression_metrics(y_true, y_pred, name="Model"):
    r2 = metrics.r2_score(y_true, y_pred)
    mae = metrics.mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(metrics.mean_squared_error(y_true, y_pred))
    print(f"\n📊 {name} Performance:")
    print(f"   R²:   {r2:.4f}")
    print(f"   MAE:  {mae:.2f}")
    print(f"   RMSE: {rmse:.2f}")
    return {"r2": r2, "mae": mae, "rmse": rmse}

metrics_lr = print_regression_metrics(y_test, y_pred_lr, name="Linear Regression")

# Plot
plt.figure(figsize=(8, 6))
sns.scatterplot(x=y_test, y=y_pred_lr, alpha=0.6)
plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")
plt.title("Linear Regression: Actual vs Predicted")
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
plt.tight_layout()
plt.show()

# %%
# CELL 7: RANDOM FOREST

rf = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
rf.fit(X_train, y_train)
y_pred_rf = rf.predict(X_test)
metrics_rf = print_regression_metrics(y_test, y_pred_rf, name="Random Forest")

# Feature importance
feat_imp = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
print("\n🏆 Top Features by Importance (Random Forest):")
display(feat_imp.head(15))

plt.figure(figsize=(10, 6))
sns.barplot(x=feat_imp.head(10).values, y=feat_imp.head(10).index, palette="viridis")
plt.title("Random Forest Feature Importances (Top 10)")
plt.xlabel("Importance")
plt.tight_layout()
plt.show()

# %%
# CELL 8: INTERACTIVE DASHBOARD 🎛️

# Create widget containers
input_widgets = {}
widget_labels = {}

# Style for the dashboard
dashboard_style = """
<style>
    .dashboard-title {
        font-size: 24px;
        font-weight: bold;
        color: #2E86AB;
        text-align: center;
        padding: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        margin-bottom: 20px;
    }
    .prediction-box {
        padding: 20px;
        border-radius: 10px;
        margin: 10px;
        text-align: center;
    }
    .lr-box {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        color: white;
    }
    .rf-box {
        background: linear-gradient(135deg, #ee0979 0%, #ff6a00 100%);
        color: white;
    }
</style>
"""

display(HTML(dashboard_style))
display(HTML('<div class="dashboard-title">🏠 House Price Prediction Dashboard</div>'))

# Create widgets for each original feature
for col in original_columns:
    dtype = original_dtypes[col]
    
    if dtype == 'object' or str(dtype) == 'category':
        # Dropdown for categorical
        unique_vals = original_df[col].dropna().unique().tolist()
        input_widgets[col] = widgets.Dropdown(
            options=unique_vals,
            value=unique_vals[0],
            description='',
            style={'description_width': 'initial'},
            layout=widgets.Layout(width='200px')
        )
    elif dtype in [np.int64, 'int64']:
        # Integer slider
        min_val = int(original_df[col].min())
        max_val = int(original_df[col].max())
        mean_val = int(original_df[col].mean())
        input_widgets[col] = widgets.IntSlider(
            value=mean_val,
            min=min_val,
            max=max_val,
            step=1,
            description='',
            style={'description_width': 'initial'},
            layout=widgets.Layout(width='300px')
        )
    else:
        # Float slider
        min_val = float(original_df[col].min())
        max_val = float(original_df[col].max())
        mean_val = float(original_df[col].mean())
        input_widgets[col] = widgets.FloatSlider(
            value=mean_val,
            min=min_val,
            max=max_val,
            step=(max_val - min_val) / 100,
            description='',
            style={'description_width': 'initial'},
            layout=widgets.Layout(width='300px'),
            readout_format='.2f'
        )
    
    widget_labels[col] = widgets.HTML(
        value=f"<b style='color:#2E86AB;'>{col}:</b>"
    )

# Output area for predictions
output = widgets.Output()

# Predict button
predict_btn = widgets.Button(
    description='🔮 Predict Price',
    button_style='success',
    layout=widgets.Layout(width='200px', height='50px'),
    style={'font_weight': 'bold'}
)

# Reset button
reset_btn = widgets.Button(
    description='🔄 Reset',
    button_style='warning',
    layout=widgets.Layout(width='100px', height='50px')
)

def predict_price(b):
    with output:
        clear_output()
        
        # Create input dataframe
        input_data = {}
        for col in original_columns:
            input_data[col] = [input_widgets[col].value]
        
        input_df = pd.DataFrame(input_data)
        
        # Apply same preprocessing
        if cat_cols:
            input_encoded = pd.get_dummies(input_df, columns=cat_cols, drop_first=True)
        else:
            input_encoded = input_df
        
        # Align columns with training data
        for col in encoded_columns:
            if col not in input_encoded.columns:
                input_encoded[col] = 0
        
        input_encoded = input_encoded[encoded_columns]
        
        # Make predictions
        pred_lr = lr.predict(input_encoded)[0]
        pred_rf = rf.predict(input_encoded)[0]
        avg_pred = (pred_lr + pred_rf) / 2
        
        # Display results
        display(HTML(f"""
        <div style="display: flex; justify-content: center; flex-wrap: wrap;">
            <div class="prediction-box lr-box">
                <h3>📈 Linear Regression</h3>
                <h2>₹ {pred_lr:,.2f}</h2>
            </div>
            <div class="prediction-box rf-box">
                <h3>🌲 Random Forest</h3>
                <h2>₹ {pred_rf:,.2f}</h2>
            </div>
        </div>
        <div style="text-align: center; margin-top: 20px; padding: 15px; 
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                    border-radius: 10px; color: white;">
            <h3>⭐ Average Prediction</h3>
            <h1>₹ {avg_pred:,.2f}</h1>
        </div>
        """))
        
        # Show input summary
        display(HTML("<h4 style='color:#2E86AB; margin-top:20px;'>📋 Your Input Summary:</h4>"))
        display(input_df.T.rename(columns={0: 'Value'}))

def reset_values(b):
    for col in original_columns:
        dtype = original_dtypes[col]
        if dtype == 'object' or str(dtype) == 'category':
            input_widgets[col].value = input_widgets[col].options[0]
        elif dtype in [np.int64, 'int64']:
            input_widgets[col].value = int(original_df[col].mean())
        else:
            input_widgets[col].value = float(original_df[col].mean())
    with output:
        clear_output()
        display(HTML("<p style='color:green;'>✅ Values reset to defaults!</p>"))

predict_btn.on_click(predict_price)
reset_btn.on_click(reset_values)

# Arrange widgets in a grid
widget_rows = []
for col in original_columns:
    row = widgets.HBox([
        widget_labels[col],
        input_widgets[col]
    ], layout=widgets.Layout(
        justify_content='space-between',
        padding='5px',
        margin='5px',
        border='1px solid #ddd',
        border_radius='5px'
    ))
    widget_rows.append(row)

# Create the dashboard layout
dashboard = widgets.VBox([
    widgets.HTML("<h3 style='color:#2E86AB;'>📝 Enter House Details:</h3>"),
    widgets.VBox(widget_rows, layout=widgets.Layout(
        padding='10px',
        border='2px solid #2E86AB',
        border_radius='10px',
        margin='10px'
    )),
    widgets.HBox([predict_btn, reset_btn], layout=widgets.Layout(
        justify_content='center',
        padding='20px'
    )),
    widgets.HTML("<hr>"),
    widgets.HTML("<h3 style='color:#2E86AB;'>🎯 Prediction Results:</h3>"),
    output
], layout=widgets.Layout(
    padding='20px',
    border='3px solid #667eea',
    border_radius='15px',
    margin='20px'
))

display(dashboard)

# %%
# CELL 9: MODEL COMPARISON SUMMARY

display(HTML("""
<div style="padding: 20px; background: #f8f9fa; border-radius: 10px; margin-top: 20px;">
    <h2 style="color: #2E86AB; text-align: center;">📊 Model Comparison Summary</h2>
</div>
"""))

comparison_df = pd.DataFrame({
    'Model': ['Linear Regression', 'Random Forest'],
    'R² Score': [metrics_lr['r2'], metrics_rf['r2']],
    'MAE': [metrics_lr['mae'], metrics_rf['mae']],
    'RMSE': [metrics_lr['rmse'], metrics_rf['rmse']]
})

display(comparison_df.style.background_gradient(cmap='RdYlGn', subset=['R² Score'])
                           .background_gradient(cmap='RdYlGn_r', subset=['MAE', 'RMSE'])
                           .format({'R² Score': '{:.4f}', 'MAE': '{:.2f}', 'RMSE': '{:.2f}'}))

# Bar chart comparison
fig, axes = plt.subplots(1, 3, figsize=(14, 4))

metrics_names = ['R² Score', 'MAE', 'RMSE']
colors = ['#11998e', '#ee0979']

for i, metric in enumerate(metrics_names):
    values = comparison_df[metric].values
    axes[i].bar(['Linear Regression', 'Random Forest'], values, color=colors)
    axes[i].set_title(metric, fontsize=14, fontweight='bold')
    axes[i].set_ylabel(metric)
    for j, v in enumerate(values):
        axes[i].text(j, v + 0.01*max(values), f'{v:.2f}', ha='center', fontweight='bold')

plt.tight_layout()
plt.show()

print("\n✅ Dashboard Ready! Adjust the sliders above and click 'Predict Price' to get predictions.")

# %%



